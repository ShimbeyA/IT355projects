<?php

class User{
    
    public $name;
}