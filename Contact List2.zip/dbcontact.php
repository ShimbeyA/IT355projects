<?php
//credantials
require 'dbcontact.php';
$servername="localhost";
$username= "sassie";
$password ="Dancers123";
$dbname="sassie_books";

//connecting to the database
try{
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    //echo 'Connected to database';
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT * FROM ContactList");
    $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $stmt->execute();
   //Set fetch mode
   
     $result = $stmt->fetchAll();
     
     foreach($result as $row){
        echo  $row['id'] . " ' >" . $row['first_name'] . ' &nbsp' .  $row['last_name'] . ', '
        . $row['email'] . '<br><br>';
	 }
}
    catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
    
    }
    
?>