<?php
$servername="localhost";
$username= "sassie";
$password ="Dancers123";
$dbname="sassie_books";

try{
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    //echo 'Connected to database';
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT last_name, first_name, email FROM ContactList");
    //$stmt->setFetchMode(PDO::FETCH_ASSOC); 
    $stmt->execute();
    // 
    
    for($i=0; $row = $stmt->fetch(); $i++){
   $id=$row['id'];
    }
}
      
    catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
    
    }
    
?>