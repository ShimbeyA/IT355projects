<?php
require_once('dbcontact.php');
 
$get_id=$_GET['ContactList'];
 
// sql to delete a record
$sql = "Delete from ContactList Where id = '$get_id'";
 
// use exec() because no results are returned
$conn->exec($sql);
header('location:contact.php');
?>