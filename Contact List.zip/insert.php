<?php
include ('dbcontact.php');
 
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$email=$_POST['email'];

 
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "INSERT INTO ContactList (first_name, last_name, email )
VALUES ('$first_name', '$last_name', '$email')";
 
$conn->exec($sql);
echo "<script>alert('Successfully Added!'); window.location='contact.php'</script>";
?>