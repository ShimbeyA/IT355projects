<?php
include 'dbcontact.php';
 
$get_id=$_REQUEST['id'];
 
$first_name= $_POST['first_name'];
$last_name= $_POST['last_name'];
$email= $_POST['email'];

 
$sql = "UPDATE ContactList SET first_name ='$first_name', last_name ='$last_name', 
 email ='$email' WHERE id= '$get_id' ";
 
$conn->exec($sql);
echo "<script>alert('Successfully Edit The Account!'); window.location='contact.php'</script>";
?>